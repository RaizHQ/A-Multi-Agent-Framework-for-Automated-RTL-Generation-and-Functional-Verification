const form=document.getElementById("firForm");
const experience=document.getElementById("experience");
const levels=document.querySelectorAll(".level");
const singleCutoff=document.getElementById("singleCutoff");
const dualFrequency=document.getElementById("dualFrequency");
const filterType=document.getElementById("filterType");
const tapMode=document.getElementById("tapMode");
const tapValueWrap=document.getElementById("tapValueWrap");
const designMethod=document.getElementById("designMethod");
const kaiserBetaWrap=document.getElementById("kaiserBetaWrap");
const source=document.getElementById("source");
const adcResolutionWrap=document.getElementById("adcResolutionWrap");
const clockDomains=document.getElementById("clockDomains");
const firClockWrap=document.getElementById("firClockWrap");

function setMode(mode){
  experience.value=mode;
  document.querySelectorAll(".advanced-only").forEach(x=>x.style.display=(mode==="advanced"||mode==="expert")?"block":"none");
  document.querySelectorAll(".expert-only").forEach(x=>x.style.display=mode==="expert"?"block":"none");
  levels.forEach(x=>x.classList.toggle("active",x.dataset.level===mode));
  updateProgress();
}
levels.forEach(x=>x.addEventListener("click",()=>setMode(x.dataset.level)));
experience.addEventListener("change",e=>setMode(e.target.value));

function conditional(){
  const type=filterType.value;
  const dual=type==="Band-pass"||type==="Band-stop";
  dualFrequency.style.display=dual?"grid":"none";
  singleCutoff.style.display=dual?"none":"flex";
  const customTaps=tapMode.value!=="auto";
  tapValueWrap.style.display=customTaps?"flex":"none";
  kaiserBetaWrap.style.display=designMethod.value==="Kaiser Window"?"flex":"none";
  adcResolutionWrap.style.display=source.value==="ADC"?"flex":"none";
  firClockWrap.style.display=clockDomains.value==="Separate clocks"?"flex":"none";
}
[filterType,tapMode,designMethod,source,clockDomains].forEach(x=>x.addEventListener("change",conditional));

function updateProgress(){
  const required=[...form.querySelectorAll("input[required],select[required],textarea[required]")].filter(x=>x.offsetParent!==null);
  const done=required.filter(x=>x.type==="checkbox"?x.checked:x.value.trim()!=="").length;
  const pct=required.length?Math.round(done/required.length*100):0;
  document.getElementById("progressBar").style.width=pct+"%";
  document.getElementById("progressText").textContent=pct+"%";
}
form.addEventListener("input",updateProgress);
form.addEventListener("change",updateProgress);

form.addEventListener("submit",e=>{
  e.preventDefault();
  const data=new FormData(form);
  const obj={};
  for(const [k,v] of data.entries()){
    if(k==="verify"||k==="output"){
      if(!obj[k])obj[k]=[];
      obj[k].push(v);
    }else obj[k]=v;
  }
  obj.generatedAt=new Date().toISOString();
  localStorage.setItem("firDesignRequest",JSON.stringify(obj,null,2));
  const blob=new Blob([JSON.stringify(obj,null,2)],{type:"application/json"});
  const url=URL.createObjectURL(blob);
  const a=document.createElement("a");
  a.href=url;a.download="fir-design-request.json";a.click();
  URL.revokeObjectURL(url);
  alert("Design specification saved as fir-design-request.json");
});

setMode("basic");
conditional();
updateProgress();
